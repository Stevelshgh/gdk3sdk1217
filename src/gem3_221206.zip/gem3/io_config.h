#ifndef __IO_CONFIG_H__
#define __IO_CONFIG_H__

//Connected LED
#define CONNECTED_LED_PORT           GPIOB
#define CONNECTED_LED_PIN            GPIO_Pin_12
#define CONNECTED_LED_PIN_Bit        12

#endif // __IO_CONFIG_H__